#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>

class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}

    Money operator+(const Money& rhs) const {
        Money res;
        res.paise = paise + rhs.paise;
        return res;
    }

    Money operator-(const Money& rhs) const {
        if (paise < rhs.paise) {
            throw std::underflow_error("Negative billing balance is not permitted!");
        }
        Money res;
        res.paise = paise - rhs.paise;
        return res;
    }

    Money& operator+=(const Money& rhs) {
        paise += rhs.paise;
        return *this;
    }

    bool operator==(const Money& rhs) const { return paise == rhs.paise; }
    bool operator<(const Money& rhs) const { return paise < rhs.paise; }

    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        os << "Rs " << (m.paise / 100) << "." << std::setw(2) << std::setfill('0') << (m.paise % 100);
        return os;
    }

    friend std::istream& operator>>(std::istream& is, Money& m) {
        long long r;
        int p;
        if (is >> r >> p) m.paise = r * 100 + p;
        return is;
    }
};

int main() {
    std::istringstream input("150 50 49 75");
    Money item1, item2;
    input >> item1 >> item2;

    Money total = item1 + item2;
    total = total - Money(20, 0);
    total += Money(5, 25);

    std::cout << "Final Bill: " << total << "\n";

    try {
        Money invalid = Money(10, 0) - Money(25, 0);
        std::cout << invalid << "\n";
    } catch (const std::exception& e) {
        std::cout << "Caught expected subtraction error: " << e.what() << "\n";
    }

    Money exactSum(0, 0), onePaisa(0, 1);
    double doubleSum = 0.0;
    for (int i = 0; i < 1000000; ++i) {
        exactSum += onePaisa;
        doubleSum += 0.01;
    }
    std::cout << "Money class (1M additions): " << exactSum << "\n";
    std::cout << std::fixed << std::setprecision(6) << "double (1M additions): Rs " << doubleSum << "\n";
    return 0;
}
