#include <iomanip>
#include <iostream>

class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}

    Money operator+(const Money& rhs) const {
        Money res;
        res.paise = this->paise + rhs.paise;
        return res;
    }

    bool operator==(const Money& rhs) const {
        return this->paise == rhs.paise;
    }

    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        long long total = m.paise;
        if (total < 0) {
            os << "-";
            total = -total;
        }
        os << "Rs " << (total / 100) << "." << std::setw(2) << std::setfill('0') << (total % 100);
        return os;
    }
};

int main() {
    Money a(120, 75), b(79, 25);
    Money c = a + b;
    std::cout << c << '\n' << std::boolalpha << (c == Money(200)) << '\n';

    Money carryTest = Money(0, 75) + Money(0, 50);
    std::cout << "Carry test (Rs 0.75 + Rs 0.50): " << carryTest << '\n';
    return 0;
}
