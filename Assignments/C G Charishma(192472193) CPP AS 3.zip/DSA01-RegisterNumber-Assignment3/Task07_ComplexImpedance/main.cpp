#include <iostream>
#include <cmath>
#include <stdexcept>
#include <iomanip>

class Complex {
    double re;
    double im;
public:
    Complex(double r = 0.0, double i = 0.0) : re(r), im(i) {}

    double real() const { return re; }
    double imag() const { return im; }
    double magnitude() const { return std::hypot(re, im); }

    Complex operator+(const Complex& rhs) const { return Complex(re + rhs.re, im + rhs.im); }
    Complex operator-(const Complex& rhs) const { return Complex(re - rhs.re, im - rhs.im); }
    Complex operator*(const Complex& rhs) const {
        return Complex(re * rhs.re - im * rhs.im, re * rhs.im + im * rhs.re);
    }

    Complex operator/(const Complex& rhs) const {
        double denom = rhs.re * rhs.re + rhs.im * rhs.im;
        if (denom < 1e-12) throw std::domain_error("Division by zero impedance (short circuit)!");
        return Complex((re * rhs.re + im * rhs.im) / denom, (im * rhs.re - re * rhs.im) / denom);
    }

    bool operator==(const Complex& rhs) const {
        return std::fabs(re - rhs.re) < 1e-9 && std::fabs(im - rhs.im) < 1e-9;
    }

    friend std::ostream& operator<<(std::ostream& os, const Complex& z) {
        os << std::fixed << std::setprecision(2) << z.re
           << (z.im >= 0 ? " + " : " - ") << std::fabs(z.im) << "j";
        return os;
    }
};

int main() {
    double f = 50.0;
    double omega = 2.0 * M_PI * f;
    Complex Z_R(100.0);
    Complex Z_L(0.0, omega * 0.5);
    Complex Z_C(0.0, -1.0 / (omega * 50e-6));

    Complex Z_series = Z_R + Z_L + Z_C;
    std::cout << "Series RLC Impedance:   " << Z_series
              << " Ohms | |Z| = " << Z_series.magnitude() << " Ohms\n";

    Complex Z_parallel = (Z_R * Z_L) / (Z_R + Z_L);
    std::cout << "Parallel R||L Impedance: " << Z_parallel
              << " Ohms | |Z| = " << Z_parallel.magnitude() << " Ohms\n";

    try {
        Complex invalid = Z_R / Complex(0.0, 0.0);
        std::cout << invalid << "\n";
    } catch (const std::exception& e) {
        std::cout << "Caught safe exception: " << e.what() << "\n";
    }
    return 0;
}
