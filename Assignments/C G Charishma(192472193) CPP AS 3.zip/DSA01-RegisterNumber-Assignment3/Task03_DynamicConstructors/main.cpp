#include <iostream>
#include <string>

class AuditoriumEvent {
private:
    std::string eventName;
    int rows;
    int cols;
    char** seatMap;

public:
    AuditoriumEvent(const std::string& name, int r, int c)
        : eventName(name), rows(r), cols(c), seatMap(nullptr) {
        std::cout << "[Constructor] Setting up '" << eventName << "' (" << rows << "x" << cols << ")\n";
        if (rows > 0 && cols > 0) {
            seatMap = new char*[rows];
            for (int i = 0; i < rows; ++i) {
                seatMap[i] = new char[cols];
                for (int j = 0; j < cols; ++j) seatMap[i][j] = 'O';
            }
        }
    }

    ~AuditoriumEvent() {
        int bookedCount = 0;
        if (seatMap != nullptr) {
            for (int i = 0; i < rows; ++i) {
                for (int j = 0; j < cols; ++j) {
                    if (seatMap[i][j] == 'B') bookedCount++;
                }
                delete[] seatMap[i];
            }
            delete[] seatMap;
        }
        std::cout << "[Destructor] Closing '" << eventName << "'. Released memory. Final Booked Seats: "
                  << bookedCount << "/" << (rows * cols) << "\n";
    }

    bool bookSeat(int r, int c) {
        if (seatMap && r >= 0 && r < rows && c >= 0 && c < cols && seatMap[r][c] == 'O') {
            seatMap[r][c] = 'B';
            return true;
        }
        return false;
    }

    bool cancelSeat(int r, int c) {
        if (seatMap && r >= 0 && r < rows && c >= 0 && c < cols && seatMap[r][c] == 'B') {
            seatMap[r][c] = 'O';
            return true;
        }
        return false;
    }

    size_t memoryAllocatedBytes() const {
        if (rows <= 0 || cols <= 0) return 0;
        return sizeof(char*) * rows + sizeof(char) * rows * cols;
    }
};

int main() {
    AuditoriumEvent mainEvent("Tech Symposium", 5, 10);
    mainEvent.bookSeat(0, 0);
    mainEvent.bookSeat(1, 2);

    {
        AuditoriumEvent workshop("AI Workshop", 3, 4);
        workshop.bookSeat(0, 1);
    }

    AuditoriumEvent* concert = new AuditoriumEvent("Symphony Night", 10, 20);
    concert->bookSeat(2, 5);
    concert->cancelSeat(2, 5);
    delete concert;

    AuditoriumEvent emptyEvent("Virtual Webinar", 0, 10);

    int dims[3][2] = {{10, 20}, {100, 200}, {1000, 2000}};
    for (auto& d : dims) {
        AuditoriumEvent temp("Calc", d[0], d[1]);
        std::cout << "Dimensions " << d[0] << "x" << d[1]
                  << " -> Heap Memory: " << temp.memoryAllocatedBytes() << " bytes\n";
    }
    return 0;
}
