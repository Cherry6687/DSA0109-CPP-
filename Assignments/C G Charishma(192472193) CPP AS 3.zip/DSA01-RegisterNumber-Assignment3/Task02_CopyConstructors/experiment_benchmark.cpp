#include <iostream>
#include <string>
#include <chrono>

int copy_count = 0;

class Prescription {
    int n;
    std::string* medicines;
public:
    explicit Prescription(int count) : n(count), medicines(new std::string[count]) {
        for (int i = 0; i < n; ++i) medicines[i] = "Med_" + std::to_string(i);
    }

    Prescription(const Prescription& other) : n(other.n), medicines(new std::string[other.n]) {
        copy_count++;
        for (int i = 0; i < n; ++i) medicines[i] = other.medicines[i];
    }

    Prescription& operator=(const Prescription& other) {
        if (this == &other) return *this;
        std::string* new_meds = new std::string[other.n];
        for (int i = 0; i < other.n; ++i) new_meds[i] = other.medicines[i];
        delete[] medicines;
        medicines = new_meds;
        n = other.n;
        return *this;
    }

    ~Prescription() { delete[] medicines; }
    int size() const { return n; }
};

void passByValue(Prescription p) { (void)p; }
void passByConstRef(const Prescription& p) { (void)p; }

int main() {
    Prescription p10(10);
    copy_count = 0;
    passByValue(p10);
    std::cout << "Copies when passed by value: " << copy_count << "\n";

    copy_count = 0;
    passByConstRef(p10);
    std::cout << "Copies when passed by const reference: " << copy_count << "\n";

    p10 = p10;
    std::cout << "Self-assignment (p = p) succeeded safely. Size: " << p10.size() << "\n\n";

    int sizes[] = {10, 1000, 100000};
    for (int sz : sizes) {
        Prescription orig(sz);
        auto start = std::chrono::high_resolution_clock::now();
        Prescription copy_obj = orig;
        auto end = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count();
        std::cout << "Deep copy time for n = " << sz << ": " << duration << " ns\n";
    }
    return 0;
}
