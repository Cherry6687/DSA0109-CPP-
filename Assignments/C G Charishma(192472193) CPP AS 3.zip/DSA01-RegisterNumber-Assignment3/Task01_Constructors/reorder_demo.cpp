#include <iostream>
class ReorderTest {
    int first;
    int second;
public:
    ReorderTest(int val) : second(val), first(second + 1) {}
    void show() const {
        std::cout << "first = " << first << ", second = " << second << "\n";
    }
};

int main() {
    ReorderTest rt(10);
    rt.show();
    return 0;
}
