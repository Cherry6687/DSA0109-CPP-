#include <iostream>
#include <string>

class Book {
private:
    std::string title;
    std::string author;
    int copies;

public:
    Book() : Book("Untitled", "Unknown", 0) {
        std::cout << "[Default Constructor] Created empty record.\n";
    }

    explicit Book(const std::string& t) : Book(t, "Donated / Unknown", 1) {
        std::cout << "[Title-Only Constructor] Created donated book record.\n";
    }

    Book(const std::string& t, const std::string& a, int c)
        : title(t), author(a), copies(c < 0 ? 0 : c) {
        if (c < 0) {
            std::cout << "[Warning] Negative copies (" << c << ") rejected. Set to 0.\n";
        }
        std::cout << "[Full Constructor] Initialized: " << title << "\n";
    }

    void display() const {
        std::cout << "Title: " << title << " | Author: " << author << " | Copies: " << copies << "\n";
    }
};

void catalogBook(const Book& b) {
    b.display();
}

int main() {
    std::cout << "=== Q1: Library Book Records ===\n\n";
    Book b1;
    Book b2("Clean Code");
    Book b3("The C++ Programming Language", "Bjarne Stroustrup", 5);

    std::cout << "\n--- Displaying initialized objects ---\n";
    b1.display();
    b2.display();
    b3.display();

    std::cout << "\n--- Testing negative copies validation ---\n";
    Book b4("Invalid Book", "Test Author", -10);
    b4.display();

    std::cout << "\n--- Testing explicit constructor ---\n";
    catalogBook(Book("Explicitly Constructed Book"));
    return 0;
}
