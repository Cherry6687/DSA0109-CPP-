#include <iostream>
#include <cstring>
#include <string>
#include <chrono>

int text_copy_count = 0;

class Text {
    size_t len;
    char* data;
public:
    Text(const char* str = "") {
        len = std::strlen(str);
        data = new char[len + 1];
        std::strcpy(data, str);
    }

    Text(const Text& other) : len(other.len), data(new char[other.len + 1]) {
        text_copy_count++;
        std::strcpy(data, other.data);
    }

    Text& operator=(const Text& other) {
        if (this == &other) return *this;
        char* new_data = new char[other.len + 1];
        std::strcpy(new_data, other.data);
        delete[] data;
        data = new_data;
        len = other.len;
        return *this;
    }

    ~Text() { delete[] data; }

    Text operator+(const Text& rhs) const {
        Text result;
        delete[] result.data;
        result.len = len + rhs.len;
        result.data = new char[result.len + 1];
        std::strcpy(result.data, data);
        std::strcat(result.data, rhs.data);
        return result;
    }

    bool operator==(const Text& rhs) const { return std::strcmp(data, rhs.data) == 0; }
    bool operator!=(const Text& rhs) const { return !(*this == rhs); }

    friend std::ostream& operator<<(std::ostream& os, const Text& t) {
        os << t.data;
        return os;
    }
};

int main() {
    Text empty("");
    Text a("Alert: "), b("Server CPU at "), c("95%!");
    a = a;

    text_copy_count = 0;
    Text combined = a + b + c;
    std::cout << "Combined: " << combined << "\n";
    std::cout << "Copies in (a + b + c): " << text_copy_count << "\n";

    auto t1_start = std::chrono::high_resolution_clock::now();
    Text customAcc("");
    Text chunk("A");
    for (int i = 0; i < 10000; ++i) customAcc = customAcc + chunk;
    auto t1_end = std::chrono::high_resolution_clock::now();

    auto t2_start = std::chrono::high_resolution_clock::now();
    std::string stdAcc("");
    std::string stdChunk("A");
    for (int i = 0; i < 100000; ++i) stdAcc += stdChunk;
    auto t2_end = std::chrono::high_resolution_clock::now();

    std::cout << "Custom Text (10,000 '+' concatenations): "
              << std::chrono::duration_cast<std::chrono::milliseconds>(t1_end - t1_start).count() << " ms\n";
    std::cout << "std::string (100,000 '+=' concatenations): "
              << std::chrono::duration_cast<std::chrono::milliseconds>(t2_end - t2_start).count() << " ms\n";
    return 0;
}
