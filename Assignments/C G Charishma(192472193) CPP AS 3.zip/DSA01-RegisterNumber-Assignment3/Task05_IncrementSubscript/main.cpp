#include <iostream>
#include <vector>
#include <string>
#include <chrono>

class Time {
    int totalSeconds;
public:
    Time(int h = 0, int m = 0, int s = 0) : totalSeconds(h * 3600 + m * 60 + s) {}

    Time& operator++() {
        ++totalSeconds;
        return *this;
    }

    Time operator++(int) {
        Time temp = *this;
        ++totalSeconds;
        return temp;
    }

    bool operator==(const Time& other) const { return totalSeconds == other.totalSeconds; }
    bool operator<(const Time& other) const { return totalSeconds < other.totalSeconds; }

    void print() const {
        int h = (totalSeconds / 3600) % 24;
        int m = (totalSeconds % 3600) / 60;
        int s = totalSeconds % 60;
        std::cout << h << ":" << (m < 10 ? "0" : "") << m << ":" << (s < 10 ? "0" : "") << s;
    }
};

class Playlist {
    std::vector<std::string> tracks;
    std::string fallback = "[Invalid Track]";
public:
    void addTrack(const std::string& t) { tracks.push_back(t); }
    int size() const { return static_cast<int>(tracks.size()); }

    std::string& operator[](int index) {
        if (index < 0 || index >= static_cast<int>(tracks.size())) {
            std::cerr << "[Range Error] Index " << index << " out of bounds!\n";
            return fallback;
        }
        return tracks[index];
    }

    const std::string& operator[](int index) const {
        if (index < 0 || index >= static_cast<int>(tracks.size())) {
            std::cerr << "[Range Error] Const index " << index << " out of bounds!\n";
            return fallback;
        }
        return tracks[index];
    }
};

int main() {
    Time t(0, 59, 59);
    Time a = t++;
    Time b = ++t;
    std::cout << "a = "; a.print(); std::cout << ", b = "; b.print(); std::cout << ", t = "; t.print(); std::cout << "\n";

    Playlist pl;
    pl.addTrack("Track 1 - Intro");
    pl.addTrack("Track 2 - Melody");
    std::cout << "pl[0]: " << pl[0] << "\n";
    (void)pl[-1];
    (void)pl[pl.size()];

    Time bench(0, 0, 0);
    auto s1 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 10000000; ++i) ++bench;
    auto e1 = std::chrono::high_resolution_clock::now();

    auto s2 = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < 10000000; ++i) bench++;
    auto e2 = std::chrono::high_resolution_clock::now();

    std::cout << "10M Prefix (++t): "
              << std::chrono::duration_cast<std::chrono::microseconds>(e1 - s1).count() << " us\n";
    std::cout << "10M Postfix (t++): "
              << std::chrono::duration_cast<std::chrono::microseconds>(e2 - s2).count() << " us\n";
    return 0;
}
