#include <iostream>
#include <string>

struct Person {
    std::string name;
    int id;
    Person(const std::string& n, int i) : name(n), id(i) {
        std::cout << "Person Constructor (" << name << ")\n";
    }
    virtual ~Person() = default;
};

struct Student : virtual Person {
    std::string programme;
    double cgpa;
    Student(const std::string& n, int i, const std::string& prog, double c)
        : Person(n, i), programme(prog), cgpa(c) {
        std::cout << "Student Constructor\n";
    }
};

struct StaffMember : virtual Person {
    std::string department;
    double salary;
    StaffMember(const std::string& n, int i, const std::string& dept, double sal)
        : Person(n, i), department(dept), salary(sal) {
        std::cout << "StaffMember Constructor\n";
    }
};

struct TeachingAssistant : public Student, public StaffMember {
    TeachingAssistant(const std::string& n, int i, const std::string& prog, double c, const std::string& dept, double sal)
        : Person(n, i), Student(n, i, prog, c), StaffMember(n, i, dept, sal) {
        std::cout << "TeachingAssistant Constructor\n";
    }
    void display() const {
        std::cout << "TA Name: " << name << ", ID: " << id << ", Prog: " << programme 
                  << ", CGPA: " << cgpa << ", Dept: " << department << ", Salary: " << salary << "\n";
    }
};

int main() {
    std::cout << "=== Assignment 4 - Task 2: Virtual Base Class Diamond Resolution ===\n";
    TeachingAssistant ta("Ananya", 202601, "M.Tech CSE", 9.4, "AI Labs", 35000.0);
    ta.display();
    return 0;
}
