#include <iostream>

struct Account {
    double rate() const { return 3.5; }
    virtual double vrate() const { return 3.5; }
    virtual ~Account() = default;
};

struct SeniorAccount : public Account {
    double* history = new double[100];
    double rate() const { return 4.0; }
    double vrate() const override { return 4.0; }
    ~SeniorAccount() override {
        delete[] history;
        std::cout << "~SeniorAccount destructor called\n";
    }
};

int main() {
    std::cout << "=== Assignment 4 - Task 4: Polymorphism & Virtual Destructors ===\n";
    Account* accs[2] = { new Account(), new SeniorAccount() };
    for (Account* a : accs) {
        std::cout << "Rate: " << a->rate() << ", VRate: " << a->vrate() << "\n";
    }
    for (Account* a : accs) {
        delete a; // Correct virtual destructor dispatch prevents leaks
    }
    return 0;
}
