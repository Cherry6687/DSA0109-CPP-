#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <iomanip>

class Vehicle {
protected:
    std::string regNo;
    double dailyRate;
public:
    Vehicle(const std::string& r, double dr) : regNo(r), dailyRate(dr) {}
    virtual ~Vehicle() = default;
    virtual double calculateCharge(int days, bool late) const = 0;
    virtual std::string type() const = 0;
    std::string getRegNo() const { return regNo; }
};

class Car : public Vehicle {
    int seatingCapacity;
public:
    Car(const std::string& r, double dr, int seats) : Vehicle(r, dr), seatingCapacity(seats) {}
    double calculateCharge(int days, bool late) const override {
        double base = days * dailyRate;
        return late ? base * 1.15 : base;
    }
    std::string type() const override { return "Car"; }
};

class ElectricCar : public Vehicle {
    double batteryCapacity;
public:
    ElectricCar(const std::string& r, double dr, int, double bat) : Vehicle(r, dr), batteryCapacity(bat) {}
    double calculateCharge(int days, bool late) const override {
        double base = days * dailyRate * (batteryCapacity / 50.0);
        return late ? base * 1.10 : base;
    }
    std::string type() const override { return "ElectricCar"; }
};

int main() {
    std::cout << "=== Assignment 4 - Task 6: Vehicle Rental Fleet ===\n";
    std::vector<std::unique_ptr<Vehicle>> fleet;
    fleet.push_back(std::make_unique<Car>("KA01AB1234", 1500.0, 5));
    fleet.push_back(std::make_unique<ElectricCar>("KA05EF5678", 1200.0, 5, 75.0));

    for (const auto& v : fleet) {
        double chg = v->calculateCharge(3, true);
        std::cout << v->type() << " (" << v->getRegNo() << ") 3 days rental + late fee: Rs "
                  << std::fixed << std::setprecision(2) << chg << "\n";
    }
    return 0;
}
