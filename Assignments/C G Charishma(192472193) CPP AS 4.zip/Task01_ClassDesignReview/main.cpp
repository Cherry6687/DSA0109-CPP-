#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <iomanip>

class Staff {
protected:
    std::string name;
    int id;
public:
    Staff(const std::string& n, int i) : name(n), id(i) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;
    virtual void display() const {
        std::cout << "ID: " << id << ", Name: " << name;
    }
};

class Professor : public Staff {
    double basic;
    double research;
public:
    Professor(const std::string& n, int i, double b, double r)
        : Staff(n, i), basic(b), research(r) {}
    double pay() const override {
        return basic + (basic * 0.42) + research;
    }
    void display() const override {
        Staff::display();
        std::cout << " [Professor] Pay: Rs " << std::fixed << std::setprecision(2) << pay() << "\n";
    }
};

class LabAssistant : public Staff {
    double basic;
public:
    LabAssistant(const std::string& n, int i, double b)
        : Staff(n, i), basic(b) {}
    double pay() const override {
        return basic + (basic * 0.42);
    }
    void display() const override {
        Staff::display();
        std::cout << " [LabAssistant] Pay: Rs " << std::fixed << std::setprecision(2) << pay() << "\n";
    }
};

class GuestFaculty : public Staff {
    double hours;
    double rate;
public:
    GuestFaculty(const std::string& n, int i, double h, double rt)
        : Staff(n, i), hours(h), rate(rt) {}
    double pay() const override {
        return hours * rate;
    }
    void display() const override {
        Staff::display();
        std::cout << " [GuestFaculty] Pay: Rs " << std::fixed << std::setprecision(2) << pay() << "\n";
    }
};

int main() {
    std::cout << "=== Assignment 4 - Task 1: Corrected Staff Hierarchy ===\n";
    std::vector<std::unique_ptr<Staff>> staffList;
    staffList.push_back(std::make_unique<Professor>("Dr. Sharma", 101, 50000.0, 15000.0));
    staffList.push_back(std::make_unique<LabAssistant>("Ramesh", 102, 25000.0));
    staffList.push_back(std::make_unique<GuestFaculty>("Dr. Rao", 103, 40.0, 1000.0));

    for (const auto& s : staffList) {
        s->display();
    }
    return 0;
}
