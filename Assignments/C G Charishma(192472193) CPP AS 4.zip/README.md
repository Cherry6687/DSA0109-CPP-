# DSA01 - Assignment 4 (CO4: Designing Reusable Class Hierarchies)

**Compiler:** `g++ -std=c++17 -Wall -Wextra`

### Task01_ClassDesignReview
- `main.cpp` -> `main_output.txt`

### Task02_UniversityPeopleManagement
- `main.cpp` -> `main_output.txt`

### Task03_ConstructorsDerived
- `complete_the_code.cpp` -> `complete_the_code_output.txt`

### Task04_PointersDerived
- `main.cpp` -> `main_output.txt`

### Task05_PointersAndThis
- `complete_the_code.cpp` -> `complete_the_code_output.txt`

### Task06_DesignChallenge
- `main.cpp` -> `main_output.txt`
