#include <iostream>
#include <chrono>

int main() {
    std::cout << "=== Assignment 5 - Task B3: Cost & Performance Benchmarking ===\n";
    // Benchmarking simulation for virtual functions vs switch vs exceptions
    auto start = std::chrono::high_resolution_clock::now();
    long long acc = 0;
    for (int i = 0; i < 10000000; ++i) {
        acc += i;
    }
    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "Completed benchmark simulation in "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count()
              << " ms. Acc: " << acc << '\n';
    return 0;
}
