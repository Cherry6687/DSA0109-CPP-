#include <iostream>
#include <string>

class Bill {
public:
    virtual ~Bill() = default;
    virtual double total() const = 0;
    virtual std::string type() const = 0;
};

class DayCareSurgery : public Bill {
    double packagePrice;
public:
    explicit DayCareSurgery(double p) : packagePrice(p) {}
    double total() const override { return packagePrice; }
    std::string type() const override { return "DayCareSurgery"; }
};

int main() {
    std::cout << "=== Assignment 5 - Task B4: Production Extension Demo ===\n";
    DayCareSurgery dcs(25000.0);
    std::cout << "Added new bill type '" << dcs.type() << "' with charge: Rs " << dcs.total() << '\n';
    std::cout << "Extension successful without modifying existing base class code.\n";
    return 0;
}
