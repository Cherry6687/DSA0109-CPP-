#include <iostream>
class SmartCard{private:long long balance;static constexpr long long minimum=5000;public:explicit SmartCard(long long b):balance(b){}bool canTravel(long long f)const{return f>=0&&balance-f>=minimum;}bool deduct(long long f){if(!canTravel(f))return false;balance-=f;return true;}long long getBalance()const{return balance;}};
int main(){SmartCard card(10000);std::cout<<(card.deduct(3000)?"Approved":"Denied")<<" Balance="<<card.getBalance()<<" paise\n";}
