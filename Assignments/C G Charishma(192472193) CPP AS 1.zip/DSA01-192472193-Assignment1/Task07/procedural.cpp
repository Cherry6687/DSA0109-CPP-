#include <iostream>
bool canTravel(long long balance,long long fare){return fare>=0 && balance-fare>=5000;}
bool deduct(long long &balance,long long fare){if(!canTravel(balance,fare))return false;balance-=fare;return true;}
int main(){long long balance=10000;long long f=3000;if(deduct(balance,f))std::cout<<"Approved ";else std::cout<<"Denied ";std::cout<<"Balance="<<balance<<" paise\n";}
