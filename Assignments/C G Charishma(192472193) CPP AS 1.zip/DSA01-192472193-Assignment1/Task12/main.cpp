#include <iostream>
#include <array>
#include <set>
enum class Zone{Inner,Middle,Outer,Airport};constexpr std::array<long long,4> BASE={1000,2000,3000,6000};
class MonthlyPass{std::set<Zone> covered;public:MonthlyPass(Zone a,Zone b):covered{a,b}{}bool covers(Zone z)const{return covered.count(z)>0;}};
long long fare(Zone z,bool peak,bool weekend,const MonthlyPass*pass=nullptr){if(pass&&pass->covers(z))return 0;long long f=BASE[static_cast<int>(z)];if(weekend)return f-f*10/100;if(peak)return f+f*20/100;return f;}
int main(){MonthlyPass pass(Zone::Inner,Zone::Airport);std::cout<<"Airport with pass="<<fare(Zone::Airport,true,false,&pass)<<" paise\n";std::cout<<"Airport weekday peak="<<fare(Zone::Airport,true,false)<<" paise\n";std::cout<<"Outer weekend (no peak stacking)="<<fare(Zone::Outer,true,true)<<" paise\n";std::cout<<"Outer weekday peak="<<fare(Zone::Outer,true,false)<<" paise\n";}
