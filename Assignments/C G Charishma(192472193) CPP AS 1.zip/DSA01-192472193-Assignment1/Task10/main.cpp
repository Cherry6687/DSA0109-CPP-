#include <iostream>
#include <iomanip>
#include <climits>
int main(){const long long journeys[]={20000,500000,3000000};const long long farePaise=3600;for(long long n:journeys){long long exact=n*farePaise;double rupees=static_cast<double>(farePaise)/100.0;double total=rupees*n;std::cout<<n<<" journeys: integer="<<exact<<" paise, double="<<std::fixed<<std::setprecision(2)<<total<<" rupees\n";}std::cout<<"INT_MAX="<<INT_MAX<<"; 3,000,000 * 3,600 exceeds int range\n";}
