#include <iostream>
#include <climits>
#include <cstddef>
int main(){ std::cout<<"sizeof(bool)="<<sizeof(bool)<<" sizeof(char)="<<sizeof(char)<<" sizeof(int)="<<sizeof(int)<<" sizeof(long long)="<<sizeof(long long)<<" sizeof(float)="<<sizeof(float)<<" sizeof(double)="<<sizeof(double)<<'\n'; long long journeys=3000000, fare=3600; std::cout<<"Network total paise="<<journeys*fare<<'\n'; std::cout<<"INT_MAX="<<INT_MAX<<" LLONG_MAX="<<LLONG_MAX<<'\n'; }
