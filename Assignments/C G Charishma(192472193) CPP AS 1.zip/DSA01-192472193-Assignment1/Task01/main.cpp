#include <iostream>
#include <string>
using namespace std;
class SmartCard { long long balance; public: SmartCard(long long b):balance(b){} bool canTravel(long long fare) const { return balance-fare>=5000; } bool deduct(long long fare){ if(fare<0 || !canTravel(fare)) return false; balance-=fare; return true;} long long getBalance() const{return balance;} };
class Passenger { string name; bool student; public: Passenger(string n,bool s):name(n),student(s){} string getName() const{return name;} bool getsConcession() const{return student;} };
struct Journey { int fromZone,toZone,hour; };
int main(){ Passenger p("Sample Passenger",true); SmartCard c(10000); Journey j{1,2,9}; cout<<p.getName()<<" travels to zone "<<j.toZone<<" at "<<j.hour<<":00\n"; cout<<(c.deduct(800)?"Approved":"Denied")<<"; balance paise="<<c.getBalance()<<'\n'; }
