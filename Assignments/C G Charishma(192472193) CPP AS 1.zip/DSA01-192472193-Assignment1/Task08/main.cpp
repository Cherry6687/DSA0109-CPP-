#include <iostream>
#include <iomanip>
#include <limits>
int main(){int hour;std::cout<<"Enter hour (0-23): ";while(!(std::cin>>hour)||hour<0||hour>23){std::cout<<"Invalid hour. Try again: ";std::cin.clear();std::cin.ignore(std::numeric_limits<std::streamsize>::max(),'\n');}long long paise=1234;std::cout<<"Accepted hour: "<<hour<<"\nFare: Rs "<<paise/100<<'.'<<std::setw(2)<<std::setfill('0')<<paise%100<<'\n';}
