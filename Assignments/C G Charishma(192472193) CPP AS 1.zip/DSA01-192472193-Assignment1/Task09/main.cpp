#include <iostream>
#include <vector>
#include <string>
struct Case{int zone,hour;long long balance;long long expectedFare;bool expectedAllowed;};
bool peak(int h){return (h>=8&&h<10)||(h>=17&&h<20);}long long calc(int z,int h){if(z<1||z>3)return -1;long long f=z*1000LL;return peak(h)?f+f*20/100:f;}
int main(){std::vector<Case> tests={{1,7,7000,1000,true},{2,8,8000,2400,true},{3,10,10000,3000,true},{1,17,7000,1200,true},{2,20,7000,2000,true},{4,9,10000,-1,false},{3,19,8000,3600,false},{1,12,6000,1000,true}};int pass=0;for(auto t:tests){auto f=calc(t.zone,t.hour);bool allowed=f>=0&&t.balance-f>=5000;bool ok=f==t.expectedFare&&allowed==t.expectedAllowed;std::cout<<"zone="<<t.zone<<" hour="<<t.hour<<" fare="<<f<<" allowed="<<(allowed?"yes":"no")<<" test="<<(ok?"PASS":"FAIL")<<'\n';pass+=ok;}std::cout<<pass<<"/"<<tests.size()<<" tests passed\n";}
