#include <iostream>
#include <array>
enum class Zone{Inner,Middle,Outer};constexpr std::array<long long,3> FARES={1000,2000,3000};
int main(){for(auto f:FARES)std::cout<<f<<" paise ";std::cout<<"\nRecommended: long long paise, constexpr fare table, enum class, private SmartCard balance.\n";}
